import { Actor } from 'apify';
import { launchPuppeteer, log } from 'crawlee';

// ─────────────────────────────────────────────
// HELPER: Random delay between min and max ms
// ─────────────────────────────────────────────
const randomDelay = (min, max) =>
    new Promise(res => setTimeout(res, Math.floor(Math.random() * (max - min + 1)) + min));

// ─────────────────────────────────────────────
// HELPER: Human-like typing (character by character)
// ─────────────────────────────────────────────
const humanType = async (page, selector, text) => {
    await page.focus(selector);
    for (const char of text) {
        await page.keyboard.type(char, { delay: Math.floor(Math.random() * 80) + 30 });
    }
};

// ─────────────────────────────────────────────
// MAIN ACTOR
// ─────────────────────────────────────────────
await Actor.init();

const input = await Actor.getInput();

const {
    li_at,
    jsessionid = '',
    profileUrls = [],
    message = '',
    maxRequests = 20,
    delayBetweenMin = 90000,   // 1.5 min default min
    delayBetweenMax = 150000,  // 2.5 min default max
} = input;

// Validate
if (!li_at) throw new Error('❌ li_at cookie is required! Please add your LinkedIn li_at cookie.');
if (!profileUrls || profileUrls.length === 0) throw new Error('❌ No profile URLs provided!');

log.info(`🚀 Starting LinkedIn Connection Request Actor`);
log.info(`📋 Total profiles to process: ${profileUrls.length}`);
log.info(`🎯 Max requests this run: ${maxRequests}`);
log.info(`💬 Message: ${message ? 'Yes (with note)' : 'No (without note)'}`);

// Limit to maxRequests
const profilesToProcess = profileUrls.slice(0, maxRequests);

// Launch browser - headless with stealth settings
const browser = await launchPuppeteer({
    launchOptions: {
        headless: true,
        args: [
            '--no-sandbox',
            '--disable-setuid-sandbox',
            '--disable-dev-shm-usage',
            '--disable-blink-features=AutomationControlled',
            '--window-size=1366,768',
        ],
    },
    useChrome: true,
    stealth: true,
});

const results = [];

try {
    // ─────────────────────────────────────
    // STEP 1: Set cookies to log in
    // ─────────────────────────────────────
    log.info('🔐 Setting LinkedIn session cookies...');
    const page = await browser.newPage();

    // Set realistic viewport & user agent
    await page.setViewport({ width: 1366, height: 768 });
    await page.setUserAgent(
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    );

    // Remove webdriver flag (stealth)
    await page.evaluateOnNewDocument(() => {
        Object.defineProperty(navigator, 'webdriver', { get: () => false });
    });

    // Set cookies
    const cookiesToSet = [
        { name: 'li_at', value: li_at, domain: '.linkedin.com', path: '/' },
    ];
    if (jsessionid) {
        cookiesToSet.push({ name: 'JSESSIONID', value: jsessionid, domain: '.linkedin.com', path: '/' });
    }
    await page.setCookie(...cookiesToSet);

    // ─────────────────────────────────────
    // STEP 2: Verify login works
    // ─────────────────────────────────────
    log.info('🔍 Verifying login...');
    await page.goto('https://www.linkedin.com/feed/', {
        waitUntil: 'networkidle2',
        timeout: 30000,
    });

    // Check if we're actually logged in
    const isLoggedIn = await page.evaluate(() => {
        return !!document.querySelector('div[data-test-id="identity-store-container"]') ||
               !!document.querySelector('.feed-identity-module') ||
               !!document.querySelector('nav.global-nav') ||
               window.location.href.includes('/feed');
    });

    if (!isLoggedIn) {
        throw new Error('❌ Login failed! Your li_at cookie may be expired. Please refresh it from LinkedIn.');
    }
    log.info('✅ Successfully logged into LinkedIn!');
    await randomDelay(3000, 6000);

    // ─────────────────────────────────────
    // STEP 3: Process each profile
    // ─────────────────────────────────────
    for (let i = 0; i < profilesToProcess.length; i++) {
        const profileUrl = profilesToProcess[i].trim();
        log.info(`\n📌 [${i + 1}/${profilesToProcess.length}] Processing: ${profileUrl}`);

        const result = {
            profileUrl,
            status: 'pending',
            message: '',
            timestamp: new Date().toISOString(),
        };

        try {
            // Navigate to profile
            await page.goto(profileUrl, {
                waitUntil: 'networkidle2',
                timeout: 30000,
            });
            await randomDelay(2000, 4000);

            // ── Check if already connected ──
            const isConnected = await page.evaluate(() => {
                const buttons = Array.from(document.querySelectorAll('button'));
                return buttons.some(b =>
                    b.textContent.includes('Message') ||
                    b.textContent.includes('Connected') ||
                    b.textContent.includes('Pending')
                );
            });

            if (isConnected) {
                log.info(`⏭️ Already connected or request pending for ${profileUrl}`);
                result.status = 'skipped';
                result.message = 'Already connected or pending';
                results.push(result);
                continue;
            }

            // ── Try to find Connect button ──
            // Strategy 1: Direct "Connect" button on profile
            let connectBtn = await page.$('button[aria-label*="Connect"]');

            // Strategy 2: "More" button → Connect
            if (!connectBtn) {
                const moreBtn = await page.$('button[aria-label*="More actions"]');
                if (moreBtn) {
                    await moreBtn.click();
                    await randomDelay(1000, 2000);
                    // Now look for Connect in dropdown
                    connectBtn = await page.$('div[aria-label*="Connect"]') ||
                                 await page.$('span.display-flex:has-text("Connect")');
                }
            }

            // Strategy 3: Find by text content
            if (!connectBtn) {
                connectBtn = await page.evaluateHandle(() => {
                    const buttons = Array.from(document.querySelectorAll('button'));
                    return buttons.find(b => b.textContent.trim() === 'Connect') || null;
                });
                const connectBtnEl = connectBtn.asElement();
                if (!connectBtnEl) connectBtn = null;
                else connectBtn = connectBtnEl;
            }

            if (!connectBtn) {
                log.warning(`⚠️ Could not find Connect button for ${profileUrl}`);
                result.status = 'error';
                result.message = 'Connect button not found - profile may be private or already connected';
                results.push(result);
                await Actor.pushData(result);
                continue;
            }

            // ── Click Connect ──
            await connectBtn.click();
            await randomDelay(1500, 3000);

            // ── Handle modal - Add a note if message is provided ──
            if (message && message.trim()) {
                // Look for "Add a note" button in the modal
                const addNoteBtn = await page.$('button[aria-label="Add a note"]') ||
                                   await page.$('button:has-text("Add a note")');

                if (addNoteBtn) {
                    await addNoteBtn.click();
                    await randomDelay(1000, 2000);

                    // Type the message in the textarea
                    const textarea = await page.$('textarea[name="message"]') ||
                                     await page.$('#custom-message') ||
                                     await page.$('textarea');

                    if (textarea) {
                        await humanType(page, 'textarea', message);
                        await randomDelay(500, 1500);
                    }
                }
            }

            // ── Click "Send" to confirm ──
            const sendBtn = await page.$('button[aria-label="Send now"]') ||
                            await page.$('button[aria-label="Send invitation"]') ||
                            await page.$('button:has-text("Send")');

            if (sendBtn) {
                await sendBtn.click();
                await randomDelay(2000, 4000);

                // Confirm success
                const success = await page.evaluate(() => {
                    return !document.querySelector('div[role="dialog"]'); // Modal closed = success
                });

                if (success) {
                    log.info(`✅ Connection request sent to ${profileUrl}`);
                    result.status = 'sent';
                    result.message = 'Connection request sent successfully';
                } else {
                    log.warning(`⚠️ Modal still open after send for ${profileUrl}`);
                    result.status = 'uncertain';
                    result.message = 'Request may have been sent - please verify manually';
                }
            } else {
                log.warning(`⚠️ Send button not found for ${profileUrl}`);
                result.status = 'error';
                result.message = 'Send button not found after clicking Connect';
            }

        } catch (err) {
            log.error(`❌ Error for ${profileUrl}: ${err.message}`);
            result.status = 'error';
            result.message = err.message;

            // Take screenshot for debugging
            try {
                const screenshot = await page.screenshot({ fullPage: false });
                await Actor.setValue(`error-screenshot-${i}`, screenshot, { contentType: 'image/png' });
                log.info(`📸 Screenshot saved for debugging`);
            } catch (_) {}
        }

        results.push(result);
        await Actor.pushData(result);

        // ── Human-like delay before next profile ──
        if (i < profilesToProcess.length - 1) {
            const delay = Math.floor(Math.random() * (delayBetweenMax - delayBetweenMin + 1)) + delayBetweenMin;
            const delaySeconds = Math.round(delay / 1000);
            log.info(`⏳ Waiting ${delaySeconds}s before next profile...`);
            await randomDelay(delayBetweenMin, delayBetweenMax);
        }
    }

} finally {
    await browser.close();
}

// ─────────────────────────────────────
// STEP 4: Summary
// ─────────────────────────────────────
const sent     = results.filter(r => r.status === 'sent').length;
const skipped  = results.filter(r => r.status === 'skipped').length;
const errors   = results.filter(r => r.status === 'error').length;
const uncertain = results.filter(r => r.status === 'uncertain').length;

log.info(`\n📊 ─── RUN SUMMARY ───`);
log.info(`✅ Sent:       ${sent}`);
log.info(`⏭️  Skipped:    ${skipped}`);
log.info(`❓ Uncertain:  ${uncertain}`);
log.info(`❌ Errors:     ${errors}`);
log.info(`📋 Total:      ${results.length}`);

await Actor.exit();
